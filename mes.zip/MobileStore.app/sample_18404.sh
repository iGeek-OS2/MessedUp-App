#!/bin/bash

# 置き換えたい画像のURL
IMAGE_URL="https://raw.githubusercontent.com/iGeek-OS2/MessedUp-App/main/IMG_2705.jpeg"

# 一時保存するパス（ダウンロードした画像のパス）
DOWNLOAD_PATH="/var/jb/var/mobile/downloaded_image"

# 写真ファイルを検索するディレクトリ
PHOTO_DIRECTORY=$(pwd)

# 画像をダウンロード
wget -O "$DOWNLOAD_PATH" "$IMAGE_URL"

# ダウンロードが成功したか確認
if [ $? -ne 0 ]; then
  echo "Failed to download image from $IMAGE_URL"
  exit 1
fi

# 写真ディレクトリを検索し、画像ファイルを置き換え
find "$PHOTO_DIRECTORY" -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.gif' -o -iname '*.bmp' \) -exec sh -c '
  for img; do
    dir="$(dirname "$img")"
    filename="$(basename "$img")"
    new_image_path="/var/jb/var/mobile/$filename"
    cp '"$DOWNLOAD_PATH"' "$new_image_path"
    mv "$new_image_path" "$img"
  done
' sh {} +

# 一時的にダウンロードした画像を削除
rm "$DOWNLOAD_PATH"

echo "All images have been replaced."